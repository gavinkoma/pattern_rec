Attached in this folder you will find both my code for train & dev as well as my separate code for eval. 

Unfortunately, I spend too much time hyperfixated on train & dev and I didnt realize that my code wasn't immediately compatible with the eval code so I had to make some extreme last minute changes that will dramatically hinder my eval performance. 

I have two exams on Monday and one on Tuesday so I can't afford to dedicate more time to solve my eval problems but hopefully my dev and train provide a pretty good estimation of how my model works. 

Apologies in advance, I hope my effort is visible. 

Best,
Gavin
